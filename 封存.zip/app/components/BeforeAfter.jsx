
"use client";

import { motion } from "framer-motion";
import ReactCompareImage from "react-compare-image";

const projects = [
  {
    before: "/before1.jpg",
    after: "/after1.jpg",
    title: "廚房喉管疏導",
    subtitle: "KITCHEN DRAIN CLEANING",
    description: "展示清除油脂、食物殘渣及排水管堵塞前後的效果。",
  },
  {
    before: "/before2.jpg",
    after: "/after2.jpg",
    title: "浴室淤塞處理",
    subtitle: "BATHROOM UNBLOCKING",
    description: "展示處理頭髮、皂垢及浴室去水不暢前後的改善效果。",
  },
];

const particles = Array.from({ length: 34 }, (_, index) => ({
  id: index,
  left: `${(index * 37) % 100}%`,
  top: `${(index * 61) % 100}%`,
  size: index % 4 === 0 ? 4 : index % 3 === 0 ? 3 : 2,
  delay: `${(index % 9) * 0.45}s`,
  duration: `${5 + (index % 7) * 0.55}s`,
  drift: `${index % 2 === 0 ? 18 + (index % 5) * 6 : -18 - (index % 5) * 6}px`,
}));

function CompareIcon() {
  const strokeProps = {
    stroke: "currentColor",
    strokeWidth: 2.4,
    strokeLinecap: "round",
    strokeLinejoin: "round",
  };

  return (
    <svg
      width="72"
      height="72"
      viewBox="0 0 72 72"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className="h-14 w-14 text-cyan-300 transition duration-300 group-hover:scale-105 group-hover:text-cyan-100"
    >
      <path {...strokeProps} d="M18 18h36v36H18V18Z" />
      <path {...strokeProps} d="M36 18v36" opacity="0.9" />
      <path {...strokeProps} d="M26 28h5" opacity="0.55" />
      <path {...strokeProps} d="M26 36h5" opacity="0.55" />
      <path {...strokeProps} d="M41 30h7" opacity="0.8" />
      <path {...strokeProps} d="M41 39h5" opacity="0.8" />
      <path {...strokeProps} d="M14 14h10" opacity="0.6" />
      <path {...strokeProps} d="M48 58h10" opacity="0.6" />
      <path {...strokeProps} d="M14 58h10" opacity="0.35" />
      <path {...strokeProps} d="M48 14h10" opacity="0.35" />
    </svg>
  );
}

export default function BeforeAfterGallery() {
  return (
    <section
      id="before-after"
      className="relative scroll-mt-24 overflow-hidden bg-[#031018] py-20 text-white"
    >
      <style jsx>{`
        @keyframes scanLine {
          0% { transform: translateY(-120%); opacity: 0; }
          12%, 88% { opacity: 0.95; }
          100% { transform: translateY(120%); opacity: 0; }
        }

        @keyframes scanGlow {
          0%, 100% { opacity: 0.28; }
          50% { opacity: 0.72; }
        }

        @keyframes particleFloat {
          0% { transform: translate3d(0, 18px, 0) scale(0.72); opacity: 0; }
          18% { opacity: 0.9; }
          72% { opacity: 0.55; }
          100% { transform: translate3d(var(--drift), -64px, 0) scale(1.05); opacity: 0; }
        }

        @keyframes particlePulse {
          0%, 100% { box-shadow: 0 0 8px rgba(103, 232, 249, 0.35); }
          50% { box-shadow: 0 0 18px rgba(103, 232, 249, 0.9); }
        }

        .compare-scan-card::before {
          content: "";
          position: absolute;
          inset: -60% 0;
          background: linear-gradient(
            180deg,
            transparent 0%,
            transparent 42%,
            rgba(103, 232, 249, 0.08) 47%,
            rgba(103, 232, 249, 0.38) 50%,
            rgba(103, 232, 249, 0.08) 53%,
            transparent 58%,
            transparent 100%
          );
          transform: translateY(-120%);
          animation: scanLine 4.8s linear infinite;
          pointer-events: none;
          z-index: 2;
        }

        .compare-scan-card::after {
          content: "";
          position: absolute;
          inset: 0;
          background-image: repeating-linear-gradient(
            180deg,
            rgba(103, 232, 249, 0.085) 0px,
            rgba(103, 232, 249, 0.085) 1px,
            transparent 1px,
            transparent 7px
          );
          mix-blend-mode: screen;
          opacity: 0.28;
          animation: scanGlow 3.2s ease-in-out infinite;
          pointer-events: none;
          z-index: 1;
        }

        .particle-dot {
          position: absolute;
          border-radius: 9999px;
          background: radial-gradient(circle, rgba(255,255,255,0.95) 0%, rgba(103,232,249,0.95) 32%, rgba(34,211,238,0.12) 72%, transparent 100%);
          animation: particleFloat var(--duration) ease-in-out infinite, particlePulse 2.4s ease-in-out infinite;
          animation-delay: var(--delay);
          pointer-events: none;
          z-index: 1;
        }
      `}</style>

      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,rgba(0,229,255,0.14),transparent_32%),linear-gradient(180deg,rgba(2,19,30,0.2),rgba(2,8,14,0.96))]" />
      <div className="absolute inset-0 opacity-[0.18] [background-image:linear-gradient(rgba(34,211,238,0.22)_1px,transparent_1px),linear-gradient(90deg,rgba(34,211,238,0.22)_1px,transparent_1px)] [background-size:44px_44px]" />
      <div className="absolute left-1/2 top-0 h-px w-[74%] -translate-x-1/2 bg-gradient-to-r from-transparent via-cyan-300/70 to-transparent" />

      <div className="absolute inset-0 overflow-hidden" aria-hidden="true">
        {particles.map((particle) => (
          <span
            key={particle.id}
            className="particle-dot"
            style={{
              left: particle.left,
              top: particle.top,
              width: `${particle.size}px`,
              height: `${particle.size}px`,
              "--delay": particle.delay,
              "--duration": particle.duration,
              "--drift": particle.drift,
            }}
          />
        ))}
      </div>

      <div className="relative z-10 mx-auto max-w-7xl px-6">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mb-10 text-center"
        >
          <div className="mb-3 flex items-center justify-center gap-4 text-cyan-300">
            <span className="h-px w-10 bg-cyan-300/70" />
            <span className="text-xs font-semibold tracking-[0.45em]">///</span>
            <span className="h-px w-10 bg-cyan-300/70" />
          </div>
          <h3 className="text-3xl font-black tracking-[0.12em] md:text-5xl">
            施工前後對比
          </h3>
          <p className="mt-2 text-xs font-semibold tracking-[0.42em] text-cyan-200/80">
            BEFORE & AFTER
          </p>
        </motion.div>

        <div className="grid gap-6 lg:grid-cols-2">
          {projects.map((project, index) => (
            <motion.article
              key={project.title}
              initial={{ opacity: 0, y: 28 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.55, delay: index * 0.08 }}
              className="compare-scan-card group relative overflow-hidden rounded-xl border border-cyan-300/30 bg-[#061b25]/78 p-5 shadow-[0_0_28px_rgba(0,216,255,0.12)] backdrop-blur transition duration-300 hover:-translate-y-1 hover:border-cyan-200/70 hover:shadow-[0_0_42px_rgba(0,216,255,0.28)]"
            >
              <div className="absolute left-3 top-3 z-[3] h-3 w-3 border-l border-t border-cyan-300/60" />
              <div className="absolute right-3 top-3 z-[3] h-3 w-3 border-r border-t border-cyan-300/60" />
              <div className="absolute bottom-3 left-3 z-[3] h-3 w-3 border-b border-l border-cyan-300/60" />
              <div className="absolute bottom-3 right-3 z-[3] h-3 w-3 border-b border-r border-cyan-300/60" />
              <div className="absolute inset-x-8 top-0 z-[3] h-px bg-gradient-to-r from-transparent via-cyan-300/80 to-transparent" />
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,rgba(34,211,238,0.18),transparent_48%)] opacity-70" />

              <div className="relative z-[4] mb-5 flex items-center gap-4">
                <div className="flex h-20 w-20 shrink-0 items-center justify-center rounded-lg border border-cyan-300/25 bg-cyan-300/[0.06] shadow-[inset_0_0_24px_rgba(34,211,238,0.08),0_0_26px_rgba(34,211,238,0.12)]">
                  <CompareIcon />
                </div>
                <div>
                  <h4 className="text-xl font-bold tracking-[0.08em] text-white">
                    {project.title}
                  </h4>
                  <p className="mt-1 text-[10px] font-semibold tracking-[0.18em] text-cyan-200/80">
                    {project.subtitle}
                  </p>
                </div>
              </div>

              <div className="relative z-[4] overflow-hidden rounded-lg border border-cyan-300/25 bg-black/30 shadow-[0_0_26px_rgba(34,211,238,0.10)]">
                <ReactCompareImage
                  leftImage={project.before}
                  rightImage={project.after}
                  leftImageLabel="施工前"
                  rightImageLabel="施工後"
                  sliderLineColor="#67e8f9"
                  handleSize={44}
                />
              </div>

              <div className="relative z-[4] mt-5 flex flex-wrap items-center justify-between gap-3">
                <p className="max-w-xl text-sm leading-7 text-slate-300">
                  {project.description}
                </p>
                <span className="rounded-full border border-cyan-300/40 px-3 py-1 text-[10px] font-bold tracking-[0.18em] text-cyan-200">
                  DRAG TO COMPARE
                </span>
              </div>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
}
