"use client";

import { Globe, Menu, X } from "lucide-react";
import { useState } from "react";

const navItems = [
  { label: "服務項目", mobileLabel: "Services", target: "services" },
  { label: "施工前後對比", mobileLabel: "Before / After", target: "before-after" },
  { label: "施工案例", mobileLabel: "Gallery", target: "gallery" },
  { label: "客戶評價", mobileLabel: "Reviews", target: "reviews" },
  { label: "預約服務", mobileLabel: "Booking", target: "booking" },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);

  const handleScroll = (target) => {
    const section = document.getElementById(target);

    if (section) {
      section.scrollIntoView({ behavior: "smooth", block: "start" });
      window.history.pushState(null, "", `#${target}`);
    }

    setOpen(false);
  };

  return (
    <header className="fixed left-0 top-0 z-50 w-full border-b border-cyan-300/15 bg-black/70 text-white backdrop-blur-xl">
      <nav className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
        <button
          type="button"
          onClick={() => handleScroll("home")}
          className="text-left"
          aria-label="Back to home section"
        >
          <div className="text-xl font-black tracking-widest">TUNGKUI PRO</div>
          <div className="text-[10px] tracking-[0.28em] text-cyan-200/80">
            專業廚房浴室喉管疏導服務
          </div>
        </button>

        <div className="hidden items-center gap-6 md:flex">
          {navItems.map((item) => (
            <button
              key={`${item.target}-${item.label}`}
              type="button"
              onClick={() => handleScroll(item.target)}
              className="group text-center text-sm font-semibold tracking-wider text-slate-200 transition hover:text-cyan-300"
            >
              <span>{item.label}</span>
              <span className="mt-1 block text-[9px] uppercase tracking-[0.18em] text-slate-400 group-hover:text-cyan-300">
                {item.mobileLabel}
              </span>
            </button>
          ))}
        </div>

        <div className="hidden items-center gap-2 rounded-md border border-cyan-300/50 px-3 py-2 text-xs font-semibold text-cyan-200 md:flex">
          <Globe size={14} />
          <span>中文</span>
          <span className="text-slate-500">|</span>
          <span>EN</span>
        </div>

        <button
          type="button"
          onClick={() => setOpen((value) => !value)}
          className="rounded-md border border-cyan-300/30 p-2 text-cyan-200 md:hidden"
          aria-label="Toggle navigation menu"
          aria-expanded={open}
        >
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
      </nav>

      {open && (
        <div className="border-t border-cyan-300/15 bg-black/90 px-6 py-4 md:hidden">
          <div className="flex flex-col gap-3">
            {navItems.map((item) => (
              <button
                key={`${item.target}-${item.label}`}
                type="button"
                onClick={() => handleScroll(item.target)}
                className="rounded-lg border border-cyan-300/15 bg-cyan-300/[0.04] px-4 py-3 text-left text-sm font-semibold text-slate-100"
              >
                {item.label}
                <span className="ml-2 text-[10px] uppercase tracking-[0.2em] text-cyan-300/70">
                  {item.mobileLabel}
                </span>
              </button>
            ))}
          </div>
        </div>
      )}
    </header>
  );
}
